const express = require('express');
const db = require('../db');

const router = express.Router();

// Home page
router.get('/', async (req, res) => {
  let query =
    'SELECT id, name, style_id, ml, price, cocktails, distilled_location FROM whiskeys';
  const params = [];
  if (req.query.name) {
    query += ' WHERE name ILIKE $1';
    params.push('%' + req.query.name + '%');
  }
  if (req.query.ml) {
    query += ' WHERE mL >= $1';
    params.push(req.query.ml);
  }
  if (req.query.price) {
    query += ' WHERE price <= $1 ';
    params.push(req.query.price);
  }

  if (req.query.sort === 'name') {
    query += ' ORDER BY name';
  } else if (req.query.sort === 'ml') {
    query += ' ORDER BY ml DESC';
  } else if (req.query.sort === 'price') {
    query += ' ORDER BY price DESC';
  }
  const result = await db.query(query, params);

  res.render('index', { title: 'Whiskeys', rows: result.rows });
});

router.get('/whiskeys/create', async (req, res) => {
  const query = 'SELECT id, style FROM whiskey_styles';
  const result = await db.query(query);
  res.render('new-whiskey-form', { styles: result.rows });
});

router.post('/whiskeys', async (req, res) => {
  const query =
    'INSERT INTO whiskeys (name, style_id, price, ml, cocktails, distilled_location) VALUES ($1, $2, $3, $4, $5, $6)';
  const parameters = [
    req.body.name,
    req.body.style_id,
    req.body.price,
    req.body.ml,
    req.body.cocktails,
    req.body.distilled_location,
  ];

  await db.query(query, parameters);

  res.render('new-whiskey-result', {
    query,
    parameters: JSON.stringify(parameters),
  });
});

router.get('/whiskeys/view/:id', async (req, res) => {
  const query = 'SELECT * FROM whiskeys WHERE id = $1;';
  const parameters = [req.params.id];
  const result = await db.query(query, parameters);

  res.render('whiskey-info', { title: 'More Information', rows: result.rows });
});

router.get('/whiskeys/edit/:id', async (req, res) => {
  const query = 'SELECT * FROM whiskeys WHERE id = $1;';
  const dropDownQuery = 'SELECT id, style FROM whiskey_styles;';
  const parameters = [req.params.id];
  const result = await db.query(query, parameters);
  const dropDown = await db.query(dropDownQuery);

  for (let i = 0; i < dropDown.rows.length; i++) {
    if (result.rows[0].style_id === dropDown.rows[i].id) {
      dropDown.rows[i].selected = true;
    }
  }

  res.render('edit-whiskey', {
    title: 'Edit',
    whiskey: result.rows[0],
    dropdown: dropDown.rows,
  });
});

router.post('/whiskeys/:id', async (req, res) => {
  const query =
    'UPDATE whiskeys SET name = $2, style_id = $3, price = $4, ml = $5, cocktails = $6, distilled_location = $7 WHERE id = $1;';
  const parameters = [
    req.params.id,
    req.body.name,
    req.body.style_id,
    req.body.price,
    req.body.ml,
    req.body.cocktails,
    req.body.distilled_location,
  ];

  await db.query(query, parameters);

  res.render('new-whiskey-result', {
    query,
    parameters: JSON.stringify(parameters),
  });
});
module.exports = router;
