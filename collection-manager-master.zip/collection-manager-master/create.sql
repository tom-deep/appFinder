CREATE TABLE whiskey_styles (
    id serial PRIMARY KEY,
    style text, 
    information text
);

CREATE TABLE whiskeys (
    id serial PRIMARY KEY,
    style_id integer REFERENCES whiskey_styles (id),
    name text NOT NULL,
    price numeric CHECK (price > 0), 
    mL int,
    cocktails text,
    distilled_location text
);

INSERT INTO whiskey_styles (style, information) VALUES ('Irish Whiskey', 'The word whiskey comes from the Irish uisce beatha, which means Water of Life. Irish Whiskey is made from barley, which means it has a lighter flavor and ages well.');

INSERT INTO whiskey_styles (style, information) VALUES ('Tennessee Whiskey', 'Tennessee Whiskey is primarily made of corn and uses the Lincoln County Process, which gives the whiskey its unique charcoal mellowing.');

INSERT INTO whiskey_styles (style, information) VALUES ('Scotch', 'Scotch comes from Scotland. There are two types of scotch, malt and grain. To qualify as Scotch, the drink must be distilled in Scotland and aged for at least three years in one day in oak casks.');

INSERT INTO whiskeys (name, style_id, price, cocktails, mL, distilled_location) VALUES ('Jack Daniels', 2, 21.97, 'Lynchburg Lemonade', 750, 'Lynchburg, TN');

INSERT INTO whiskeys (name, style_id, price, cocktails, mL, distilled_location) VALUES ('Jameson', 1, 25.98, 'Irish Gold', 750, 'Dublin, Ireland');

INSERT INTO whiskeys (name, style_id, price, cocktails, mL, distilled_location) VALUES ('Grants', 3, 16.99, 'Rob Roy', 750, 'Dufftown, Scottland');